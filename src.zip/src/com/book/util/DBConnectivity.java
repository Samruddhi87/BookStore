package com.book.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectivity {
	/**
	 * This method is used to connect to database. It returns connection object if
	 * connected to database, null otherwise
	 * 
	 * @return connection
	 */
	public static Connection makeConnection() {
		Connection connection = null;
		try {
			connection = DriverManager.getConnection(
					"jdbc:mysql://localhost:2017/BookStoreDB_CTOL35?user=root&password=root&useSSL=false");
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return connection;
	}
}
